<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HabitacionActivo extends Model
{
    protected $fillable = [
    'numero_habitacion', 'piso', 
    'ap_modelo', 'ap_serie', 'ap_mac', 'ap_ip',
    'tv_marca', 'tv_modelo', 'tv_serie', 'tv_pulgadas', 
    'control_remoto_estado', 'control_serie', // Actualizado
    'caja_fuerte_modelo', 'caja_fuerte_serie', 'caja_fuerte_bateria',
    'notas_tecnicas'
];
}
