<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id', 'area', 'descripcion', 'prioridad', 'status', 
        'archivo_path', 'notas_admin', 'fecha_resolucion'
    ];

    // Relación: Un ticket pertenece a un usuario
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}