<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Asset extends Model
{
    use HasFactory;

    protected $fillable = [
        'nombre', 'nomenclatura', 'area', 'encargado', 'ip_address', 'status', 'notas', 'pdf_path', 'imagen_path',
        'division', 'tipo_equipo', 'marca', 'modelo', 'numero_serie', 'fecha_adquisicion', 'factura',
        'procesador', 'ram', 'tipo_ram', 'almacenamiento', 'sistema_operativo', 'paqueteria_office',
        'monitor_marca', 'monitor_modelo', 'monitor_ns',
        'mouse_marca', 'mouse_modelo', 'mouse_ns',
        'teclado_marca', 'teclado_modelo', 'teclado_ns'
    ];

    public function revisions()
    {
        return $this->hasMany(Revision::class);
    }
}