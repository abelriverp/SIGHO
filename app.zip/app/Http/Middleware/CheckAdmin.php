<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckAdmin
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next): Response
    {
        // Verificamos que el usuario tenga sesión iniciada Y sea administrador
        if (auth()->check() && (auth()->user()->email === 'admin@emporio.com' || auth()->user()->role === 'admin')) {
            // Si todo está bien, lo dejamos pasar a la ruta que pidió
            return $next($request);
        }

        // Si no es admin, le bloqueamos el paso
        abort(403, 'No tienes permisos de Administrador para ver esta página.');
    }
}