<?php
namespace App\Http\Controllers;

use App\Models\Ticket;
use App\Models\User;
use App\Notifications\NuevoTicketNotification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Notification;
use Barryvdh\DomPDF\Facade\Pdf;


class TicketController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        // FILTRO DE PRIVACIDAD
        if ($user->role === 'admin' || $user->email === 'admin@emporio.com') {
            // El admin ve TODO
            $ticketsAbiertos = Ticket::where('status', 'Abierto')->latest()->get();
            $ticketsResueltos = Ticket::where('status', 'Resuelto')->latest()->get();
        } else {
            // El usuario normal SOLO ve sus propios tickets
            $ticketsAbiertos = Ticket::where('status', 'Abierto')->where('user_id', $user->id)->latest()->get();
            $ticketsResueltos = Ticket::where('status', 'Resuelto')->where('user_id', $user->id)->latest()->get();
        }

        return view('tickets.index', compact('ticketsAbiertos', 'ticketsResueltos'));
    }

    public function create()
    {
        return view('tickets.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'area' => 'required|string|max:255', // El área física del hotel
            'departamento_destino' => 'required|string', // A quién va dirigido (Sistemas, Manto, etc)
            'descripcion' => 'required|string',
            'prioridad' => 'required|string',
            'archivo' => 'nullable|file|mimes:jpeg,png,jpg,mp4,mov|max:20480',
        ]);

        if ($request->hasFile('archivo')) {
            $data['archivo_path'] = $request->file('archivo')->store('evidencias_tickets', 'public');
        }

        $data['user_id'] = auth()->id(); 
        $data['status'] = 'Abierto';

        // NOTA: Si no tienes la columna 'departamento_destino' en tu DB, 
        // puedes concatenarla en la descripción o agregarla a tu migración.
        $ticket = Ticket::create($data);

        $admins = User::where('role', 'admin')->orWhere('email', 'admin@emporio.com')->get();
        Notification::send($admins, new NuevoTicketNotification($ticket));

        return redirect()->route('tickets.index')->with('success', 'Reporte creado con éxito.');
    }

    public function show($id)
    {
        $ticket = Ticket::findOrFail($id);
        $user = auth()->user();

        // BLOQUEO DE SEGURIDAD PARA LA URL
        if ($user->role !== 'admin' && $user->email !== 'admin@emporio.com' && $ticket->user_id !== $user->id) {
            abort(403, 'No tienes permiso para ver este ticket.');
        }

        return view('tickets.show', compact('ticket'));
    }

    public function resolve(Request $request, $id)
    {
        $request->validate(['notas_admin' => 'required|string']);

        $ticket = Ticket::findOrFail($id);
        $ticket->update([
            'status' => 'Resuelto',
            'notas_admin' => $request->notas_admin,
            'fecha_resolucion' => now(),
        ]);

        return redirect()->route('tickets.index')->with('success', 'Ticket marcado como resuelto.');
    }
    public function downloadPDF($id)
{
    $ticket = Ticket::with('user')->findOrFail($id);
    $base64 = null;

    // Si el ticket tiene imagen y existe en el disco
    if ($ticket->archivo_path && Storage::disk('public')->exists($ticket->archivo_path)) {
        $path = storage_path('app/public/' . $ticket->archivo_path);
        $type = pathinfo($path, PATHINFO_EXTENSION);
        
        // Solo procesamos si es imagen (no video)
        if (in_array(strtolower($type), ['jpg', 'jpeg', 'png', 'webp'])) {
            $data = file_get_contents($path);
            $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
        }
    }

    $pdf = Pdf::loadView('tickets.pdf', compact('ticket', 'base64'))
              ->setPaper('letter', 'portrait');

    return $pdf->download('Ticket_#' . $ticket->id . '.pdf');
}
}