<?php

namespace App\Http\Controllers;

use App\Models\Asset;
use App\Models\Revision;
use Illuminate\Http\Request;

class RevisionController extends Controller
{
    public function create(Asset $asset)
    {
        return view('revisions.create', compact('asset'));
    }
    public function store(Request $request, Asset $asset)
    {
        $request->validate(['problema' => 'required']);

        $asset->revisions()->create($request->all());

        return redirect()->route('assets.show', $asset->id);
    }

    public function edit(Revision $revision)
    {
        return view('revisions.edit', compact('revision'));
    }

    public function update(Request $request, Revision $revision)
    {
        $revision->update($request->all());
        return redirect()->route('assets.show', $revision->asset_id);
    }


    public function destroy(Revision $revision)
    {
        $assetId = $revision->asset_id;
        $revision->delete();
        return redirect()->route('assets.show', $assetId);
    }
}