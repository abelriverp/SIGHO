<?php

namespace App\Http\Controllers;

use App\Models\NetworkDevice;
use App\Models\NetworkPort;
use Illuminate\Http\Request;

class NetworkController extends Controller
{
    public function index()
    {
        $devices = NetworkDevice::withCount('ports')->latest()->get();
        return view('network.index', compact('devices'));
    }

    public function create()
    {
        return view('network.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'nombre' => 'required|string|max:255',
            'tipo' => 'required|string',
            'total_ports' => 'required|integer|min:4',
            'ubicacion' => 'nullable|string|max:255'
        ]);

        $device = NetworkDevice::create($data);

        for ($i = 1; $i <= $data['total_ports']; $i++) {
            NetworkPort::create([
                'network_device_id' => $device->id,
                'port_number' => $i,
                'status' => 'Libre'
            ]);
        }

        return redirect()->route('network.index');
    }

    public function show($id)
    {
        // AQUÍ ESTÁ EL CAMBIO: Ordenamos los puertos siempre por su número (1, 2, 3...)
        $device = NetworkDevice::with(['ports' => function($query) {
            $query->orderBy('port_number', 'asc');
        }])->findOrFail($id);

        return view('network.show', compact('device'));
    }

    // Esta función actualiza si un puerto está ocupado o libre
    public function updatePort(Request $request, $id)
    {
        $port = NetworkPort::findOrFail($id);
        
        $port->update([
            'connected_to' => $request->connected_to,
            'speed' => $request->speed ?? 'Gigabit', // Guardamos la velocidad
            'status' => !empty($request->connected_to) ? 'Ocupado' : 'Libre' 
        ]);

        return back();
    }
    
    public function destroy($id)
    {
        NetworkDevice::findOrFail($id)->delete();
        // Los puertos se borran solos gracias al "onDelete('cascade')" de la base de datos
        return redirect()->route('network.index');
    }
}