<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function showLogin()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    { 
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ]);
    
        if (Auth::attempt($credentials)) {
            $request->session()->regenerate(); 
            
            // ==========================================
            // LÓGICA DE VALIDACIÓN DE ROLES ACTUALIZADA
            // ==========================================
            $user = Auth::user();

            // Si es el admin original O si tiene el rol de administrador en la BD
            if ($user->email === 'admin@emporio.com' || $user->role === 'admin') {
                // Lo mandamos a la pantalla principal de inventario
                return redirect()->route('assets.index'); 
            } else {
                // Si es empleado normal: Lo mandamos directo a crear su ticket
                return redirect()->route('tickets.create'); 
            }
        }  

        return back()->withErrors([
            'email' => 'Las credenciales no coinciden.',
        ])->onlyInput('email');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/login');
    }
}