<?php

namespace App\Http\Controllers;

use App\Models\HabitacionActivo;
use Illuminate\Http\Request;

class HabitacionActivoController extends Controller
{
    // Vista principal: Lista por pisos
    public function index()
    {
        // Agrupamos las habitaciones por piso para la vista
        $piso1 = HabitacionActivo::where('piso', 1)->orderBy('numero_habitacion')->get();
        $piso2 = HabitacionActivo::where('piso', 2)->orderBy('numero_habitacion')->get();
        $piso3 = HabitacionActivo::where('piso', 3)->orderBy('numero_habitacion')->get();
        $piso4 = HabitacionActivo::where('piso', 4)->orderBy('numero_habitacion')->get();

        return view('inventory.habitaciones', compact('piso1', 'piso2', 'piso3', 'piso4'));
    }

    // Guardar una nueva habitación
    public function store(Request $request)
    {
        $data = $request->validate([
            'numero_habitacion' => 'required|unique:habitacion_activos',
            'piso' => 'required|integer',
            'ap_modelo' => 'nullable|string',
            'ap_serie' => 'nullable|string',
            'ap_mac' => 'nullable|string',
            'tv_modelo' => 'nullable|string',
            'tv_serie' => 'nullable|string',
            'control_serie' => 'nullable|string',
            'caja_fuerte_serie' => 'nullable|string',
        ]);

        HabitacionActivo::create($data);
        return back()->with('success', 'Habitación registrada correctamente.');
    }

    // Actualizar datos técnicos de una habitación
    public function update(Request $request, $id)
    {
        $hab = HabitacionActivo::findOrFail($id);
        $hab->update($request->all());
        
        return back()->with('success', 'Inventario de la habitación #' . $hab->numero_habitacion . ' actualizado.');
    }
}