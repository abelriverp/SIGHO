<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Area;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AdminSettingsController extends Controller
{
    // =====================================
    // MÓDULO DE USUARIOS
    // =====================================
    public function usersIndex() {
        $users = User::latest()->get();
        return view('admin.users.index', compact('users'));
    }

    public function usersCreate() {
        return view('admin.users.form');
    }

    public function usersStore(Request $request) {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6',
            'role' => 'required|in:admin,usuario'
        ]);

        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => $request->role,
        ]);
        return redirect()->route('admin.users.index')->with('success', 'Usuario creado correctamente.');
    }

    public function usersEdit($id) {
        $user = User::findOrFail($id);
        return view('admin.users.form', compact('user'));
    }

    public function usersUpdate(Request $request, $id) {
        $user = User::findOrFail($id);
        
        $rules = [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,'.$id,
            'role' => 'required|in:admin,usuario'
        ];
        
        if ($request->filled('password')) {
            $rules['password'] = 'min:6';
        }

        $request->validate($rules);

        $user->name = $request->name;
        $user->email = $request->email;
        $user->role = $request->role;
        
        if ($request->filled('password')) {
            $user->password = Hash::make($request->password);
        }
        
        $user->save();
        return redirect()->route('admin.users.index')->with('success', 'Usuario actualizado correctamente.');
    }

    public function usersDestroy($id) {
        $user = User::findOrFail($id);
        if ($user->email === 'admin@emporio.com') {
            return back()->with('error', 'No puedes eliminar al administrador principal.');
        }
        $user->delete();
        return back()->with('success', 'Usuario eliminado.');
    }

    // =====================================
    // MÓDULO DE ÁREAS
    // =====================================
    public function areasIndex() {
        $areas = Area::latest()->get();
        return view('admin.areas.index', compact('areas'));
    }

    public function areasCreate() {
        return view('admin.areas.form');
    }

    public function areasStore(Request $request) {
        $request->validate(['nombre' => 'required|string|unique:areas']);
        Area::create(['nombre' => $request->nombre]);
        return redirect()->route('admin.areas.index')->with('success', 'Área agregada correctamente.');
    }

    public function areasEdit($id) {
        $area = Area::findOrFail($id);
        return view('admin.areas.form', compact('area'));
    }

    public function areasUpdate(Request $request, $id) {
        $area = Area::findOrFail($id);
        $request->validate(['nombre' => 'required|string|unique:areas,nombre,'.$id]);
        $area->update(['nombre' => $request->nombre]);
        return redirect()->route('admin.areas.index')->with('success', 'Área actualizada correctamente.');
    }

    public function areasDestroy($id) {
        Area::findOrFail($id)->delete();
        return back()->with('success', 'Área eliminada.');
    }
}